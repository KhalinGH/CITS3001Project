
## Dependencies

GraphStream is the Java library used in this project for visualisation.

The dependency files used are:

* gs-core-2.0.jar
* gs-ui-swing-2.0.jar

These file can be downloaded at: https://graphstream-project.org/download/
